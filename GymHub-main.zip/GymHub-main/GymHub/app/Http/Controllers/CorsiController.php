<?php

namespace App\Http\Controllers;

use App\Models\corsi;
use App\Http\Requests\StorecorsiRequest;
use App\Http\Requests\UpdatecorsiRequest;

class CorsiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorecorsiRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(corsi $corsi)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(corsi $corsi)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatecorsiRequest $request, corsi $corsi)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(corsi $corsi)
    {
        //
    }
}
